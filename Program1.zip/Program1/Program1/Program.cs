﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    //Class:CIS-199-02
    //Assignment:Program 1 
    //Grade Id:R2235
    //1/15/2022
    internal class Program
    {//This program will allow the user to calculate the cost of building a shed
        static void Main(string[] args)
        {
            int lengthFrontInput;//The front length input
            
            int lengthSideInput;// The Side length input
           
            int lengthHeightInput;//The height length input


    
            int addWindowInput;//The window input
           
            double dryWallInput;//The drywall input
            
            double laborCostInput;//The cost of Labor input
            double laborCost;//Labor cost as a double so it can be used later in the code
            const double windowFee = 100.0;//The window fee set as a constant so it can be calculated
            double sqFeet;//The square feet as a double
            double materialCost;//the material costs as a double
            double totalCost;//the overall cost of everything
            

            Console.WriteLine("Welcome to the Dry Wall and Window Installation Calculator\n");//The introduction to the calculator
            Console.WriteLine("Enter the length of the front (in feet):");//Prompts the user to enter the length of the front
            lengthFrontInput =Convert.ToInt32(Console.ReadLine());//Captures the users input for the front
            Console.WriteLine("Enter the length of the side (in feet):");//Prompts the user to enter the length of the side
            lengthSideInput = Convert.ToInt32(Console.ReadLine());//captures the users input for the side
            Console.WriteLine("Enter the height(in feet)");//Prompts the user to enter the height
            lengthHeightInput = Convert.ToInt32(Console.ReadLine());//captures the users input for the height
            Console.WriteLine("Enter 1 if you want a window, Enter 0 if you do not:");//Prompts the user to input if they would like a window or not
            addWindowInput = Convert.ToInt32(Console.ReadLine());//capturs the users input for wether they would like a window or not
            Console.WriteLine("Enter cost of Dry Wall per square foot:");//prompts the user to enter the cost fo the dry wall
            dryWallInput = Convert.ToDouble(Console.ReadLine());//captures the users input for the cost of dry wall
            Console.WriteLine("Enter cost of labor per square feet"); //prompts the user to enter the cost of labor per square feet
            laborCostInput =Convert.ToDouble(Console.ReadLine());//captures the cost of labor input
            Console.WriteLine("\n");//line break
            sqFeet = Convert.ToDouble(lengthHeightInput * lengthFrontInput * 2 + lengthHeightInput * lengthSideInput * 2 + lengthFrontInput * lengthSideInput);//formula for the overall square feet
            Console.WriteLine("Total Sqaure feet needed: " + sqFeet.ToString(" 0,0.00 "));//Takes the total square feet and inputs it as the solution to the prompt
            double extrasqFeet=sqFeet*1.1;//formula for the extra 10%
            Console.WriteLine("10% Extra Square feet: " + extrasqFeet.ToString("0,0.00"));//Outputs the 10% extra square feet in the correct format 
            laborCost = (extrasqFeet * (double)laborCostInput);//Formula for the cost of labor
            Console.WriteLine("Labor cost:" +laborCost.ToString("C"));//outputs the labor cost and converts it to currency
            materialCost = dryWallInput *sqFeet*1.1;//Formula for the material cost
            Console.WriteLine("Material cost: " + materialCost.ToString("C"));//Outputs the material costs and converts it to currency
            double windowInput = windowFee * addWindowInput;//Formula for the window fee, if the user indicated wether they would like a window or not
            totalCost = laborCost + materialCost + windowInput;//The overall cost of building a shed's formula
            Console.WriteLine("Total cost: " + totalCost.ToString("C"));//Outputs the overall cost and converts it to currency
             
          

            

             

            
                

        }
    }
}
