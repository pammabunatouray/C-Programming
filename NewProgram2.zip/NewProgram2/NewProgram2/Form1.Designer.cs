﻿namespace NewProgram2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GuestBoxT = new System.Windows.Forms.Label();
            this.guestBoxinput = new System.Windows.Forms.TextBox();
            this.nightBox = new System.Windows.Forms.Label();
            this.starBox = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nightsBoxinput = new System.Windows.Forms.TextBox();
            this.starRating = new System.Windows.Forms.ComboBox();
            this.costTotal = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.costTotalout = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // GuestBoxT
            // 
            this.GuestBoxT.AutoSize = true;
            this.GuestBoxT.Location = new System.Drawing.Point(145, 60);
            this.GuestBoxT.Name = "GuestBoxT";
            this.GuestBoxT.Size = new System.Drawing.Size(66, 13);
            this.GuestBoxT.TabIndex = 0;
            this.GuestBoxT.Text = "Guest Count";
            // 
            // guestBoxinput
            // 
            this.guestBoxinput.Location = new System.Drawing.Point(252, 52);
            this.guestBoxinput.Name = "guestBoxinput";
            this.guestBoxinput.Size = new System.Drawing.Size(100, 20);
            this.guestBoxinput.TabIndex = 1;
            // 
            // nightBox
            // 
            this.nightBox.AutoSize = true;
            this.nightBox.Location = new System.Drawing.Point(145, 103);
            this.nightBox.Name = "nightBox";
            this.nightBox.Size = new System.Drawing.Size(37, 13);
            this.nightBox.TabIndex = 2;
            this.nightBox.Text = "Nights";
            // 
            // starBox
            // 
            this.starBox.AutoSize = true;
            this.starBox.Location = new System.Drawing.Point(145, 146);
            this.starBox.Name = "starBox";
            this.starBox.Size = new System.Drawing.Size(60, 13);
            this.starBox.TabIndex = 3;
            this.starBox.Text = "Star Rating";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(152, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Hotel Cost:";
            // 
            // nightsBoxinput
            // 
            this.nightsBoxinput.Location = new System.Drawing.Point(252, 96);
            this.nightsBoxinput.Name = "nightsBoxinput";
            this.nightsBoxinput.Size = new System.Drawing.Size(100, 20);
            this.nightsBoxinput.TabIndex = 5;
            // 
            // starRating
            // 
            this.starRating.FormattingEnabled = true;
            this.starRating.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.starRating.Location = new System.Drawing.Point(252, 146);
            this.starRating.Name = "starRating";
            this.starRating.Size = new System.Drawing.Size(121, 21);
            this.starRating.TabIndex = 6;
            // 
            // costTotal
            // 
            this.costTotal.AutoSize = true;
            this.costTotal.Location = new System.Drawing.Point(267, 217);
            this.costTotal.Name = "costTotal";
            this.costTotal.Size = new System.Drawing.Size(0, 13);
            this.costTotal.TabIndex = 7;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(193, 182);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // costTotalout
            // 
            this.costTotalout.AutoSize = true;
            this.costTotalout.Location = new System.Drawing.Point(270, 217);
            this.costTotalout.Name = "costTotalout";
            this.costTotalout.Size = new System.Drawing.Size(0, 13);
            this.costTotalout.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.costTotalout);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.costTotal);
            this.Controls.Add(this.starRating);
            this.Controls.Add(this.nightsBoxinput);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.starBox);
            this.Controls.Add(this.nightBox);
            this.Controls.Add(this.guestBoxinput);
            this.Controls.Add(this.GuestBoxT);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label GuestBoxT;
        private System.Windows.Forms.TextBox guestBoxinput;
        private System.Windows.Forms.Label nightBox;
        private System.Windows.Forms.Label starBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox nightsBoxinput;
        private System.Windows.Forms.ComboBox starRating;
        private System.Windows.Forms.Label costTotal;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label costTotalout;
    }
}

