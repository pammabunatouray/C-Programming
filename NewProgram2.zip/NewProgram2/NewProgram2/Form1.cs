﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NewProgram2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Grade Id: R2235
            //Class: CIS 199-02
            // Due Date: 3/11/2022
            //This program will allow a user to estimate the cost of a hotel
            //Program 2
            const double FLATONE = 100;//Flat fee for 1 gues
            const double FLATTWO = 150;//Flat fee for 2 guests
            const double FLATTHREE = 250;//Flat fee for 3 guests
            const double FLATFOUR = 400;//Flat fee for 4 or more guests
            const double DAILY = 100;//Daily fee for someone staying less than 7 days
            const double WEEKLY = 75;//Daily fee for someone staying less than a month but more than 7 days
            const double MONTHLY = 25;//Dails fee for someone staying more than 30 days
            double nightCounttotal = 0;//The total number of nights someone is styaing
            double costTotal = 0;//The overall cost total
            double starFactor;//The fee correlating to how many stars the hotel has
            double guestcountFee = 0;//The fee correlating to the number of guests



            
            if (int.TryParse(guestBoxinput.Text, out int guestcount) && guestcount >= 1 && guestcount <= 7)//Will only allow guest count from 1 to 7
            {
                if (int.TryParse(nightsBoxinput.Text, out int nightcount))
                {
                    {//If the guest count is equal to a certain number they will be charged with the correlating fee
                        if (guestcount == 1)
                            guestcountFee = FLATONE;

                        else if (guestcount == 2)
                            guestcountFee = FLATTWO;

                        else if (guestcount == 3)
                            guestcountFee = FLATTHREE;

                        else
                            guestcountFee = FLATFOUR;
                    }//If the night count is within a specific range of numbers than they will be charged a correlating fee
                    {
                        if (nightcount >= 1 && nightcount <= 7)
                            nightCounttotal = DAILY * nightcount;

                        else if (nightcount >= 7 && nightcount <= 30)
                            nightCounttotal = WEEKLY * nightcount;

                        else
                            nightCounttotal = MONTHLY * nightcount;
                    }
                    {//if a star rating from the dropdown menu is picked, they will be charged a fee correlating to that star rating

                        string starRatings = starRating.Text;

                        if (starRatings == "1")

                            starFactor = 1;



                        else if (starRatings == "2")

                            starFactor = 1.5;



                        else if (starRatings == "3")

                            starFactor = 2.5;



                        else if (starRatings == "4")

                            starFactor = 3;



                        else

                            starFactor = 4;


                    }
                    costTotal = (guestcountFee + nightCounttotal) * starFactor;//The cost total formula

                    costTotalout.Text = $"{costTotal:C}";//The cost toal outputted in currency form


                }
                else
                    MessageBox.Show("Invalid");
            }
            else
                MessageBox.Show("Invalid");

        }



    }
}

