﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgramThree
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] gardenType = { "Premium", "Standard", "Discount" };
        double[] baseRate = { 1.1, 1, 0.9 };

        int[] flowerNumbers = { 10001, 10002, 10003, 10004, 10005, 10006, 10007 };

        double[] flowercost = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 };

        double[] quantity = { 6, 16, 21 };

        double[] percentFullprice = { 0.95, 0.90, 0.85 };

        private void button1_Click(object sender, EventArgs e)
        {
            //gardenLabel,gardenCombobox
            //fnumberLabel,fnumberLabelinput
            //quantityLabel,quantityLabelinput
            //flowerCost,flowerCostoutput
            //baseCost,baseCostoutput
            //discountPercent,discountPercentoutput
            //totalPrice,totalPriceoutput

            
            bool gardenTypes = false;
            bool fNumbers = false;
            bool quantitytype = false;
            if (int.TryParse(fnumberLabelinput.Text, out int fNumber) && fNumber >= 10001 && fNumber <= 10007)
                if (int.TryParse(quantityLabelinput.Text, out int fquantity) && fquantity >= 0)
                    if (gardenCombobox.SelectedIndex >= 0)
                    {
                        double gRate = baseRate[gardenCombobox.SelectedIndex];
                        for (int i = 0; i < gardenType.Length; i++)
                        {
                            if (gardenCombobox.SelectedIndex <= -1)
                            {
                                MessageBox.Show("Error");
                            }
                            if (gardenCombobox.SelectedIndex == 0)
                            {
                                gardenTypes = true;
                                gRate = baseRate[i];
                            }
                            if (gardenCombobox.SelectedIndex == 1)
                            {
                                gardenTypes = true;
                                gRate = baseRate[i];
                            }
                            if (gardenCombobox.SelectedIndex == 2)
                            {
                                gardenTypes = true;
                                gRate = baseRate[i];
                            }

                            double flowerCosts = 0;

                            for (int x = 0; x < flowerNumbers.Length; x++)
                            {
                                if (Convert.ToInt32(fnumberLabelinput.Text) == flowerNumbers[x])
                                {
                                    fNumbers = true;
                                    flowerCosts = flowercost[x];

                                }
                            }

                            double quantityCost = 0;

                            for (int x = 0; x < quantity.Length; x++)
                            {
                                if (Convert.ToInt32(quantityLabelinput.Text) == quantity[x])
                                {
                                    fNumbers = true;
                                    quantityCost = percentFullprice[x];

                                }
                            }
                            double flowerCost = flowerCosts * quantityCost;
                            double baseCost = flowerCost * gRate;
                            double totalPrice = baseCost * quantityCost;
                            flowerCostoutput.Text = $"{flowerCost:C}";
                            baseCostoutput.Text = $"{baseCost:C}";
                            discountPercentoutput.Text = $"{quantityCost:P}";
                            totalPriceoutput.Text = $"{totalPrice:C}";

                        }

                    }




        }
    
    }
}
